
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROC [DBO].[PR_GET_TableInfo]
as

SET NOCOUNT ON

DECLARE @dbname varchar(50),@dbid INT,@servername VARCHAR(50),@sql VARCHAR(4000)
SET @servername ='10.1.120.87,2'
CREATE TABLE #db (dbname varchar(50), dbid int)
INSERT INTO #db SELECT name ,dbid FROM master.dbo.sysdatabases WHERE dbid >4
SELECT top 1 @dbid = dbid from #db
WHILE(@dbid >0 )
BEGIN
	SELECT TOP 1 @dbname = dbname FROM #db WHERE dbid = @dbid
	SET @sql = '
		INSERT INTO [AutoCheck].[dbo].[T_Table]([ServerName]
			  ,[DBName]
			  ,[TableName]
			  ,[Colorder]
			  ,[ColumnName]
			  ,[ColumnDescribe]
			  ,[ColumnType]
			  ,[ColumnLen]
			  ,[ColumnScale]
			  ,[ColumnIsIdentity]
			  ,[Column_PK]
			  ,[ColumnISNULL]
			  ,[ColumnDefault])
		SELECT  '''+@dbname+''',
				'''+@servername+''',
				obj.name AS 表名,
				col.colorder AS 序号 ,
				col.name AS 列名 ,
				ISNULL(ep.[value], '''') AS 列说明 ,
				t.name AS 数据类型 ,
				col.length AS 长度 ,
				ISNULL(COLUMNPROPERTY(col.id, col.name, ''Scale''), 0) AS 小数位数 ,
				CASE WHEN COLUMNPROPERTY(col.id, col.name, ''IsIdentity'') = 1 THEN 1
					 ELSE ''''
				END AS 标识 ,
				CASE WHEN EXISTS ( SELECT   1
						FROM ['+@dbname+'].dbo.sysindexes si
							INNER JOIN ['+@dbname+'].dbo.sysindexkeys sik ON si.id = sik.id AND si.indid = sik.indid
							INNER JOIN ['+@dbname+'].dbo.syscolumns sc ON sc.id = sik.id  AND sc.colid = sik.colid
							INNER JOIN ['+@dbname+'].dbo.sysobjects so ON so.name = si.name AND so.xtype = ''PK''
						WHERE sc.id = col.id AND sc.colid = col.colid ) THEN 1
					 ELSE ''''
				END AS 主键 ,
				CASE WHEN col.isnullable = 1 THEN 1
					 ELSE ''''
				END AS 允许空 ,
				ISNULL(comm.text, '''') AS 默认值
				--into T_table
		FROM    ['+@dbname+'].dbo.syscolumns col
				LEFT  JOIN ['+@dbname+'].dbo.systypes t ON col.xtype = t.xusertype
				INNER JOIN ['+@dbname+'].dbo.sysobjects obj ON col.id = obj.id AND obj.xtype = ''U'' AND obj.status >= 0
				LEFT  JOIN ['+@dbname+'].dbo.syscomments comm ON col.cdefault = comm.id
				LEFT  JOIN ['+@dbname+'].sys.extended_properties ep ON col.id = ep.major_id AND col.colid = ep.minor_id AND ep.name = ''MS_Description''
				LEFT  JOIN ['+@dbname+'].sys.extended_properties epTwo ON obj.id = epTwo.major_id AND epTwo.minor_id = 0 AND epTwo.name = ''MS_Description''
		--WHERE   obj.name = ''Mas_AccountGeetestIdKey''--表名
		WHERE obj.name <> ''MSreplication_options''
		AND obj.name not like ''MSpeer_%''
		AND obj.name <> ''sysarticles''
		AND obj.name <> ''syssubscriptions''
		AND obj.name <> ''systranschemas'' 
		AND obj.name <> ''sysarticlecolumns'' 
		AND obj.name <> ''sysarticleupdates'' 
		AND obj.name <> ''sysschemaarticles'' 
		AND obj.name <> ''syspublications'' 
		AND obj.name <> ''sysdiagrams'' 
		AND obj.name <> ''sysreplservers'' 
		AND obj.name <> ''MSpub_identity_range'' 
		ORDER BY obj.name, col.colorder'
	--PRINT @sql
	EXEC (@sql)
	DELETE FROM #db WHERE dbid = @dbid
	SET @dbid =0
	SELECT TOP 1 @dbid = dbid FROM #db
	--PRINT @dbid
END
DROP TABLE #db

go

