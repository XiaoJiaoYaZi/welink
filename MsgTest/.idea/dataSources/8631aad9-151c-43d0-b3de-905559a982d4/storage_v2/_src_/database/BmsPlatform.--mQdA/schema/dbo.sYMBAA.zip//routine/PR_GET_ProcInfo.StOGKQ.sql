
-- =============================================
-- Author:		高存良
-- Create date: 20180423
-- Description:	获取存储过程和视图的详细内容
-- =============================================
CREATE PROC [dbo].[PR_GET_ProcInfo]
AS

	SET NOCOUNT ON

	DECLARE @dbname VARCHAR(50),@dbid INT,@servername VARCHAR(50),@sql VARCHAR(4000)

	SET @servername ='10.1.120.87,2'
	CREATE TABLE #db (dbname VARCHAR(50), DBID INT)
	
	INSERT INTO #db SELECT name ,dbid FROM master.dbo.sysdatabases WHERE dbid >4
	SELECT TOP 1 @dbid = dbid FROM #db
	
	WHILE(@dbid >0 )
	BEGIN
		SELECT TOP 1 @dbname = dbname FROM #db WHERE dbid = @dbid
		SET @sql = '
		INSERT INTO [AutoCheck].[dbo].[T_Proc]([ServerName]
		  ,[DBName]
		  ,[Name]
		  ,[Xtype]
		  ,[Colid]
		  ,[Text])
		SELECT '''+@servername+''', '''+@dbname+''',a.name,a.xtype,b.colid,b.text 
		FROM '+@dbname+'..sysobjects a,'+@dbname+'..syscomments b 
		WHERE a.id=b.id AND a.xtype IN(''V'',''P'') AND a.status>=0'
		--PRINT @sql
		EXEC (@sql)
		DELETE FROM #db WHERE dbid = @dbid
		SET @dbid =0
		SELECT top 1 @dbid = dbid FROM #db
		--PRINT @dbid
	END
	DROP TABLE #db


go

