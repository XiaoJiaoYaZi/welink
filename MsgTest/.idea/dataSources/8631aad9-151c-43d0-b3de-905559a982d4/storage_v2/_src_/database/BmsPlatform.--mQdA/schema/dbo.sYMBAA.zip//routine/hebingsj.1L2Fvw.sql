CREATE function [dbo].[hebingsj] (@msgid bigint)
 returns varchar(1000)
 as
 begin
 declare @r varchar(1000)
 set @r=''
 select @r=@r+rtrim(cast(MobilePhone as varchar))+',' from Mas_HistoryMsgInfo  where msgid=@msgid
 return(@r)
 end

go

